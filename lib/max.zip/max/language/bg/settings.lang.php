<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

// Installer translation strings
$GLOBALS['strWarning'] = "Предупреждение";







/* ------------------------------------------------------- */
/* Configuration translations                            */
/* ------------------------------------------------------- */

// Global

// Configuration Settings

// Administrator Settings
$GLOBALS['strBasicInformation'] = "Основна информация";

// Database Settings

// Email Settings

// Audit Trail Settings

// Debug Logging Settings

// Delivery Settings
$GLOBALS['strTypeFTPUsername'] = "Вход";
$GLOBALS['strTypeFTPPassword'] = "Парола";

// General Settings

// Geotargeting Settings

// Interface Settings
$GLOBALS['strInventory'] = "Инвентар";
$GLOBALS['strHideInactive'] = "Скрий неактивните";

// Invocation Settings

// Banner Delivery Settings

// Banner Logging Settings

// Banner Storage Settings

// Campaign ECPM settings

// Statistics & Maintenance Settings

// UI Settings

// Regenerate Platfor Hash script

// Plugin Settings
