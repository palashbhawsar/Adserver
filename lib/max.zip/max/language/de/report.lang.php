<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

// Error messages
$GLOBALS['strReportErrorMissingSheets'] = "Für diesen Bericht wurde kein Arbeitsblatt ausgewählt";
$GLOBALS['strReportErrorUnknownCode'] = "Unbekannter Fehler Nr. #";
