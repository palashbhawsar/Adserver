<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

// Other
$GLOBALS['strChooseTypeOfInvocation'] = "Dewiswch y math o actifadu baneri";
$GLOBALS['strChooseTypeOfBannerInvocation'] = "Dewiswch y math o actifadu baneri";

// Measures

// Common Invocation Parameters
$GLOBALS['strInvocationCampaignID'] = "Ymgyrch";
$GLOBALS['strInvocationSource'] = "Ffynhonnell";

// Iframe

// PopUp
$GLOBALS['strShowStatus'] = "Statws";

// XML-RPC

// Support for 3rd party server clicktracking

// Support for cachebusting code

// IMG invocation selected for tracker with appended code
$GLOBALS['strWarning'] = "Rhybudd";

// Local Invocation

