<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

// Error messages
$GLOBALS['strReportErrorMissingSheets'] = "Aucune feuille de calcul n'a été sélectionnée pour le rapport";
$GLOBALS['strReportErrorUnknownCode'] = "Code erreur inconnu N°";
