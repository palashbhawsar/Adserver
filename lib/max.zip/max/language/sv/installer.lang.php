<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

/** status messages * */

/** welcome step * */

/** check step * */


$GLOBALS['strWarning'] = "Varning";

/** admin login step * */

/** database step * */


/** config step * */

/** jobs step * */


/** finish step * */

$GLOBALS['strUnableCreateConfFile'] = "Vi lyckades inte skapa din konfigurationsfil. Vänligen kontrollera rättigheterna till {$PRODUCT_NAME} var mappen.";
$GLOBALS['strUnableUpdateConfFile'] = "Vi lyckades inte uppdatera din konfigurationsfil. Vänligen kontrollera rättigheterna till {$PRODUCT_NAME} var mappen samt kontrollera rättigheterna i tidigare installations konfigurationsfil som kan ha kopierats till den här mappen.";

