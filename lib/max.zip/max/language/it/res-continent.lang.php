<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$phpAds_cont_name['AS'] = 'Asia';
$phpAds_cont_name['EU'] = 'Europa';
$phpAds_cont_name['AF'] = 'Africa';
$phpAds_cont_name['OC'] = 'Australia/Oceania';
$phpAds_cont_name['CA'] = 'Caraibi';
$phpAds_cont_name['SA'] = 'America del Sud';
$phpAds_cont_name['NA'] = 'America del Nord';
$phpAds_cont_name['AQ'] = 'Antartide';

?>