<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

/** status messages * */

/** welcome step * */

/** check step * */


$GLOBALS['strWarning'] = "تحذير";
$GLOBALS['strSyscheckStatus'] = "الحالة";

/** admin login step * */

/** database step * */


/** config step * */

/** jobs step * */


/** finish step * */


