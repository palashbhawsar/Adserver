<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$GLOBALS['strPluginAffiliate'] 		= "Сгенерировать обозрение истории выбранного издателя. Отчёт экспортируется в формате CSV для использования в электронной таблице.";
$GLOBALS['strPluginCampaign'] 		= "Сгенерировать обозрение истории выбранной кампании. Отчёт экспортируется в формате CSV для использования в электронной таблице.";
$GLOBALS['strPluginClient'] 		= "Сгенерировать обозрение истории выбранного рекламодателя. Отчёт экспортируется в формате CSV для использования в электронной таблице.";
$GLOBALS['strPluginGlobal'] 		= "Сгенерировать обозрение глобальной истории. Отчёт экспортируется в формате CSV для использования в электронной таблице.";
$GLOBALS['strPluginZone'] 		= "Сгенерировать обозрение истории выбранной зоны. Отчёт экспортируется в формате CSV для использования в электронной таблице.";



// Note: new translatiosn not found in original lang files but found in CSV


// Note: New translations not found in original lang files but found in CSV
$GLOBALS['strPublisherHistoryDescription'] = "Отправлять отчеты об распределении по сайтам клиенту";
$GLOBALS['strPublisherZoneHistoryDescription'] = "Отправлять отчеты об распределении по сайтам и зонам клиенту";
$GLOBALS['strPublisherConversionTrackingAnalysisDescription'] = "Этот отчет показывает распределение конверсии для отдельного сайта (партнера)";
?>