<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

// Note: New translations not found in original lang files but found in CSV
$GLOBALS['strPublisherHistoryDescription'] = "Relatório de distribuição por sites de um anunciante";
$GLOBALS['strPublisherZoneHistoryDescription'] = "Relatório de distribuição por sites e zonas de um anunciante";
$GLOBALS['strPublisherConversionTrackingAnalysisDescription'] = "Este relatório apresenta detalhes de toda atividade de rastreamento de conversões de um site (afiliado)";
?>