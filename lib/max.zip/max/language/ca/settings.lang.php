<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

// Installer translation strings







/* ------------------------------------------------------- */
/* Configuration translations                            */
/* ------------------------------------------------------- */

// Global

// Configuration Settings

// Administrator Settings

// Database Settings

// Email Settings

// Audit Trail Settings

// Debug Logging Settings

// Delivery Settings

// General Settings

// Geotargeting Settings

// Interface Settings
$GLOBALS['strInventory'] = "Inventari";

// Invocation Settings

// Banner Delivery Settings

// Banner Logging Settings

// Banner Storage Settings

// Campaign ECPM settings

// Statistics & Maintenance Settings

// UI Settings

// Regenerate Platfor Hash script

// Plugin Settings
