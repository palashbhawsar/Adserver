<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

// Other

// Measures

// Common Invocation Parameters
$GLOBALS['strInvocationCampaignID'] = "Καμπάνια";
$GLOBALS['strInvocationSource'] = "Πηγή";

// Iframe

// PopUp
$GLOBALS['strShowStatus'] = "Κατάσταση";

// XML-RPC

// Support for 3rd party server clicktracking

// Support for cachebusting code

// IMG invocation selected for tracker with appended code
$GLOBALS['strWarning'] = "Προειδοποίηση";

// Local Invocation

