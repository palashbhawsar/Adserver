<?php

/*
  +---------------------------------------------------------------------------+
  | Revive Adserver                                                           |
  | http://www.revive-adserver.com                                            |
  |                                                                           |
  | Copyright: See the COPYRIGHT.txt file.                                    |
  | License: GPLv2 or later, see the LICENSE.txt file.                        |
  +---------------------------------------------------------------------------+
 */

// Settings help translation strings

















$GLOBALS['phpAds_hlp_content_gzip_compression'] = "GZIP 컨텐츠 압축을 활성화하면 관리 페이지가 열릴 때마다 전송되는 콘텐츠의 양이 크게 감소합니다.
이 기능을 활성화하시려면 GZIP 확장이 설치되어 있어야 합니다.";


































































